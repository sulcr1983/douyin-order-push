import os
import sqlite3
import requests
import logging
from datetime import datetime, timedelta
from dotenv import load_dotenv

load_dotenv()

logger = logging.getLogger(__name__)

DB_FILES = {
    'Qmaster': os.getenv('DB_FILE_QMASTER', 'orders_qmaster.db'),
    'tianyixinxuan': os.getenv('DB_FILE_TIANYIXINXUAN', 'orders_tianyixinxuan.db')
}

WECOM_ROBOT_WEBHOOK = os.getenv('WECOM_ROBOT_WEBHOOK', '')

WECOM_CORP_ID = os.getenv('WECOM_CORP_ID', '')
WECOM_AGENT_ID = os.getenv('WECOM_AGENT_ID', '')
WECOM_SECRET = os.getenv('WECOM_SECRET', '')


class OrderAnalyzer:
    def __init__(self):
        self.db_files = DB_FILES
        self.webhook = WECOM_ROBOT_WEBHOOK
        self.corp_id = WECOM_CORP_ID
        self.agent_id = WECOM_AGENT_ID
        self.secret = WECOM_SECRET

    def _get_connection(self, db_file):
        if not os.path.exists(db_file):
            return None
        return sqlite3.connect(db_file)

    def _get_date_range(self):
        today = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
        yesterday = today - timedelta(days=1)
        return today, yesterday

    def _timestamp_to_date(self, timestamp):
        try:
            ts = int(timestamp) / 1000
            return datetime.fromtimestamp(ts).strftime('%Y-%m-%d')
        except:
            return None

    def get_today_overview(self, conn):
        today, yesterday = self._get_date_range()
        today_str = today.strftime('%Y-%m-%d')

        query = """
            SELECT COUNT(*), SUM(merchant_income)
            FROM orders
            WHERE payment_time IS NOT NULL
            AND payment_time != ''
            AND date(payment_time/1000, 'unixepoch', 'localtime') = ?
        """

        try:
            cursor = conn.execute(query, (today_str,))
            result = cursor.fetchone()
            order_count = result[0] or 0
            total_gmv = result[1] or 0.0
            aov = total_gmv / order_count if order_count > 0 else 0
            return {
                'order_count': order_count,
                'total_gmv': total_gmv,
                'aov': aov,
                'date': today_str
            }
        except Exception as e:
            logger.error(f"获取今日概况失败: {e}")
            return {'order_count': 0, 'total_gmv': 0.0, 'aov': 0.0, 'date': today_str}

    def get_yesterday_data(self, conn):
        today, yesterday = self._get_date_range()
        yesterday_str = yesterday.strftime('%Y-%m-%d')

        query = """
            SELECT COUNT(*), SUM(merchant_income)
            FROM orders
            WHERE payment_time IS NOT NULL
            AND payment_time != ''
            AND date(payment_time/1000, 'unixepoch', 'localtime') = ?
        """

        try:
            cursor = conn.execute(query, (yesterday_str,))
            result = cursor.fetchone()
            return {
                'order_count': result[0] or 0,
                'total_gmv': result[1] or 0.0
            }
        except Exception as e:
            logger.error(f"获取昨日数据失败: {e}")
            return {'order_count': 0, 'total_gmv': 0.0}

    def get_growth_rate(self, today_gmv, yesterday_gmv):
        if yesterday_gmv <= 0:
            return None
        return ((today_gmv - yesterday_gmv) / yesterday_gmv) * 100

    def get_product_ranking(self, conn, limit=3):
        today, yesterday = self._get_date_range()
        today_str = today.strftime('%Y-%m-%d')

        query = """
            SELECT product_name, SUM(quantity) as total_qty
            FROM orders
            WHERE payment_time IS NOT NULL
            AND payment_time != ''
            AND date(payment_time/1000, 'unixepoch', 'localtime') = ?
            AND product_name IS NOT NULL
            AND product_name != ''
            GROUP BY product_name
            ORDER BY total_qty DESC
            LIMIT ?
        """

        try:
            cursor = conn.execute(query, (today_str, limit))
            results = cursor.fetchall()
            return [(row[0], row[1]) for row in results]
        except Exception as e:
            logger.error(f"获取商品排行失败: {e}")
            return []

    def get_pending_orders(self, conn):
        query = """
            SELECT COUNT(*)
            FROM orders
            WHERE (order_status LIKE '%待发货%' OR order_status LIKE '%待出库%')
            AND shipping_time IS NULL
        """

        try:
            cursor = conn.execute(query)
            result = cursor.fetchone()
            return result[0] or 0
        except Exception as e:
            logger.error(f"获取待处理订单失败: {e}")
            return 0

    def get_shop_stats(self, shop_name, db_file):
        stats = {
            'shop_name': shop_name,
            'today_orders': 0,
            'today_gmv': 0.0,
            'aov': 0.0,
            'yesterday_gmv': 0.0,
            'growth_rate': None,
            'top_products': [],
            'pending_orders': 0
        }

        conn = self._get_connection(db_file)
        if not conn:
            return stats

        try:
            today_overview = self.get_today_overview(conn)
            stats['today_orders'] = today_overview['order_count']
            stats['today_gmv'] = today_overview['total_gmv']
            stats['aov'] = today_overview['aov']

            yesterday_data = self.get_yesterday_data(conn)
            stats['yesterday_gmv'] = yesterday_data['total_gmv']

            stats['growth_rate'] = self.get_growth_rate(
                stats['today_gmv'],
                stats['yesterday_gmv']
            )

            stats['top_products'] = self.get_product_ranking(conn, 3)
            stats['pending_orders'] = self.get_pending_orders(conn)

        finally:
            conn.close()

        return stats

    def analyze_all_shops(self):
        all_stats = {}
        total_today_gmv = 0.0
        total_today_orders = 0
        total_yesterday_gmv = 0.0
        total_pending = 0

        for shop_name, db_file in self.db_files.items():
            if not os.path.exists(db_file):
                logger.warning(f"数据库文件不存在: {db_file}")
                continue

            stats = self.get_shop_stats(shop_name, db_file)
            all_stats[shop_name] = stats

            total_today_gmv += stats['today_gmv']
            total_today_orders += stats['today_orders']
            total_yesterday_gmv += stats['yesterday_gmv']
            total_pending += stats['pending_orders']

        overall_aov = total_today_gmv / total_today_orders if total_today_orders > 0 else 0
        overall_growth = self.get_growth_rate(total_today_gmv, total_yesterday_gmv)

        return {
            'shops': all_stats,
            'total_today_gmv': total_today_gmv,
            'total_today_orders': total_today_orders,
            'total_yesterday_gmv': total_yesterday_gmv,
            'overall_aov': overall_aov,
            'overall_growth': overall_growth,
            'total_pending': total_pending
        }

    def _get_access_token(self):
        url = f"https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid={self.corp_id}&corpsecret={self.secret}"
        try:
            response = requests.get(url, timeout=10)
            data = response.json()
            if data.get('errcode') == 0:
                return data.get('access_token')
        except Exception as e:
            logger.error(f"获取access_token失败: {e}")
        return None

    def _send_to_webhook(self, markdown_content):
        if not self.webhook:
            logger.warning("未配置 WECOM_ROBOT_WEBHOOK，跳过发送")
            return False

        payload = {
            "msgtype": "markdown",
            "markdown": {
                "content": markdown_content
            }
        }

        try:
            response = requests.post(self.webhook, json=payload, timeout=10)
            result = response.json()
            if result.get('errcode') == 0:
                logger.info("经营分析报告发送成功")
                return True
            else:
                logger.error(f"发送失败: {result.get('errmsg')}")
                return False
        except Exception as e:
            logger.error(f"发送异常: {e}")
            return False

    def _send_to_agent(self, markdown_content):
        if not all([self.corp_id, self.agent_id, self.secret]):
            logger.warning("企业微信应用配置不完整，跳过发送")
            return False

        access_token = self._get_access_token()
        if not access_token:
            return False

        url = f"https://qyapi.weixin.qq.com/cgi-bin/message/send?access_token={access_token}"

        payload = {
            "touser": "@all",
            "msgtype": "markdown",
            "agentid": self.agent_id,
            "markdown": {
                "content": markdown_content
            }
        }

        try:
            response = requests.post(url, json=payload, timeout=10)
            result = response.json()
            if result.get('errcode') == 0:
                logger.info("经营分析报告发送成功")
                return True
            else:
                logger.error(f"发送失败: {result.get('errmsg')}")
                return False
        except Exception as e:
            logger.error(f"发送异常: {e}")
            return False

    def build_markdown_report(self, analysis_result):
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

        report = f"""📊 **经营分析简报**
> 🕐 统计时间: {timestamp}

---

## 🏆 成交战报

"""

        growth_text = ""
        if analysis_result['overall_growth'] is not None:
            growth_value = analysis_result['overall_growth']
            if growth_value >= 0:
                growth_text = f"环比昨日 **+{growth_value:.1f}%**"
            else:
                growth_text = f"环比昨日 **{growth_value:.1f}%**"
        else:
            growth_text = "昨日无数据，无法计算环比"

        report += f"""> **今日 GMV：¥{analysis_result['total_today_gmv']:,.2f}**
> {growth_text}

---

## 📈 流量转化

"""

        report += f"""> **今日成交笔数：{analysis_result['total_today_orders']} 单**
> **客单价（AOV）：¥{analysis_result['overall_aov']:.2f}**

"""

        all_top_products = []
        for shop_name, stats in analysis_result['shops'].items():
            for idx, (product, qty) in enumerate(stats.get('top_products', []), 1):
                all_top_products.append((idx, shop_name, product, qty))

        all_top_products.sort(key=lambda x: x[3], reverse=True)
        top3 = all_top_products[:3]

        report += """## 🔥 爆款追踪

"""

        if top3:
            medal = ["🥇", "🥈", "🥉"]
            for i, (rank, shop, product, qty) in enumerate(top3):
                report += f"""> {medal[i]} 今日 Top{i+1}：{product}
>    店铺：{shop} | 已售 **{qty} 件**

"""
        else:
            report += "> 今日暂无销售数据\n"

        report += """## ⚠️ 服务提醒

"""

        pending = analysis_result['total_pending']
        if pending > 0:
            report += f"""> 待处理异常订单：**{pending} 单**
> 请相关人员尽快核销处理！

"""
        else:
            report += "> 当前无待处理异常订单 👍\n"

        report += """---

> 💡 *本报告由订单同步系统自动生成*
"""

        return report

    def generate_and_send_report(self):
        try:
            logger.info("开始生成经营分析报告...")

            analysis_result = self.analyze_all_shops()
            markdown_report = self.build_markdown_report(analysis_result)

            if self.webhook:
                self._send_to_webhook(markdown_report)
            elif all([self.corp_id, self.agent_id, self.secret]):
                self._send_to_agent(markdown_report)
            else:
                logger.warning("未配置任何发送渠道（webhook或应用），请检查配置")
                print(markdown_report)
                return False

            return True

        except Exception as e:
            logger.error(f"生成或发送报告失败: {e}")
            return False


def run_analysis():
    analyzer = OrderAnalyzer()
    analyzer.generate_and_send_report()


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    run_analysis()
