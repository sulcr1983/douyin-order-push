# 订单同步系统

## 系统功能

- 支持多店铺订单同步（Qmaster、天颐心选）
- 自动读取 CSV 和 Excel 订单文件
- 自动过滤无效订单（已关闭、已取消、未付款等）
- 清洗和处理订单数据
- 同步数据到企业微信智能表格
- 增量同步（仅同步变更数据）
- 详细的日志记录（控制台 + 文件）

## 项目结构

```
ordersync/
├── main.py                 # 主程序
├── requirements.txt        # Python依赖
├── .env                    # 配置文件（需创建）
├── .gitignore              # Git忽略配置
├── Qmaster/                # Qmaster店铺订单文件夹
├── tianyixinxuan/          # 天颐心选店铺订单文件夹
├── 运行订单同步.bat         # Windows快速启动脚本
└── 订单同步工具.pyw         # 无窗口运行版本
```

## 快速开始

### 1. 安装依赖

```bash
pip install -r requirements.txt
```

### 2. 创建配置文件

在项目根目录创建 `.env` 文件：

```env
# Qmaster 店铺配置
WECOM_WEBHOOK_URL_QMASTER=https://qyapi.weixin.qq.com/cgi-bin/wedoc/smartsheet/webhook?key=你的Qmaster密钥
DB_FILE_QMASTER=orders_qmaster.db

# 天颐心选店铺配置
WECOM_WEBHOOK_URL_TIANYIXINXUAN=https://qyapi.weixin.qq.com/cgi-bin/wedoc/smartsheet/webhook?key=你的天颐心选密钥
DB_FILE_TIANYIXINXUAN=orders_tianyixinxuan.db
```

### 3. 准备订单文件

在项目文件夹下创建两个店铺文件夹，将订单 CSV 或 Excel 文件放入：

```
ordersync/
├── Qmaster/           # 放入 Qmaster 店铺订单
│   └── 订单2026-04-22.csv
└── tianyixinxuan/    # 放入天颐心选店铺订单
    └── 订单2026-04-22.xlsx
```

### 4. 运行程序

**方法一：双击运行（推荐）**
- 双击 `运行订单同步.bat`

**方法二：命令行运行**
```bash
python main.py
```

## 配置说明

### 可配置项（.env）

| 配置项 | 说明 | 默认值 |
|--------|------|--------|
| `WECOM_WEBHOOK_URL_QMASTER` | Qmaster店铺Webhook地址 | 无 |
| `WECOM_WEBHOOK_URL_TIANYIXINXUAN` | 天颐心选店铺Webhook地址 | 无 |
| `DB_FILE_QMASTER` | Qmaster本地数据库文件 | orders_qmaster.db |
| `DB_FILE_TIANYIXINXUAN` | 天颐心选本地数据库文件 | orders_tianyixinxuan.db |
| `EXCLUDE_ORDER_STATUSES` | 要过滤的订单状态（逗号分隔） | 已关闭,已取消,未付款,待付款,交易关闭,取消订单 |
| `MAX_CONSECUTIVE_FAILURES` | 连续失败中断阈值 | 10 |
| `LOG_FILE` | 日志文件名 | sync_log.txt |
| `LOG_LEVEL` | 日志级别 | INFO |

### 示例配置

```env
# Webhook配置
WECOM_WEBHOOK_URL_QMASTER=https://qyapi.weixin.qq.com/cgi-bin/wedoc/smartsheet/webhook?key=xxx
WECOM_WEBHOOK_URL_TIANYIXINXUAN=https://qyapi.weixin.qq.com/cgi-bin/wedoc/smartsheet/webhook?key=xxx

# 数据库配置
DB_FILE_QMASTER=orders_qmaster.db
DB_FILE_TIANYIXINXUAN=orders_tianyixinxuan.db

# 过滤配置（不区分大小写）
EXCLUDE_ORDER_STATUSES=已关闭,已取消,未付款,待付款,交易关闭,取消订单

# 容错配置
MAX_CONSECUTIVE_FAILURES=10

# 日志配置
LOG_FILE=sync_log.txt
LOG_LEVEL=INFO
```

## 数据清洗规则

### 订单状态过滤

以下状态的订单会被自动过滤，不会同步到企业微信：
- 已关闭
- 已取消
- 未付款
- 待付款
- 交易关闭
- 取消订单

### 数据标准化

- 子订单编号：去除首尾空格
- 商品ID：去除首尾空格
- 收货地址：自动合并省市区
- 金额和数量：转换为数值类型
- 快递信息：自动提取快递单号

## 日志说明

程序运行时会生成详细日志：

- **控制台输出**：INFO级别，显示主要操作和结果
- **文件输出**（sync_log.txt）：DEBUG级别，包含详细信息

日志格式：`时间 - 级别 - 消息`

示例：
```
2026-04-22 13:30:15 - INFO - 开始同步店铺: Qmaster
2026-04-22 13:30:15 - INFO - 已自动锁定最新文件: [订单2026-04-22.csv]
2026-04-22 13:30:16 - INFO - 数据对比完成：5 条需新增，2 条需更新，10 条已同步过无需处理
```

## 常见问题

### 问题1：双击批处理文件没有反应

**解决方法：**
1. 检查是否已安装 Python
2. 检查 Python 是否添加到系统环境变量
3. 右键 `运行订单同步.bat`，选择"以管理员身份运行"

### 问题2：提示"文件正在被 Excel 占用"

**解决方法：**
- 关闭正在编辑的 Excel 文件
- 如果文件无法关闭，可将文件复制一份再运行

### 问题3：同步失败怎么办

**解决方法：**
1. 检查网络连接
2. 检查 Webhook URL 是否正确
3. 查看 sync_log.txt 中的详细错误信息
4. 程序会自动重试最多3次

### 问题4：想重新同步所有数据

**解决方法：**
- 删除本地数据库文件（orders_qmaster.db 或 orders_tianyixinxuan.db）
- 程序会重新同步所有数据

## 企业微信智能表格字段映射

| 字段名 | 说明 | 数据类型 |
|--------|------|----------|
| 子订单编号 | 订单唯一标识 | 文本 |
| 商品ID | 商品编码 | 文本 |
| 商品名称 | 商品名称 | 文本 |
| 下单数量 | 购买数量 | 数字 |
| 商家收入金额 | 商家实收金额 | 数字 |
| 订单状态 | 当前状态 | 单选 |
| 下单时间 | 支付完成时间 | 时间 |
| 收货地址 | 完整收货地址 | 文本 |
| 快递信息 | 快递单号 | 文本 |
| 出库状态 | 待出库/已出库 | 单选 |

## 技术支持

如遇问题，请查看 sync_log.txt 日志文件，或联系管理员。
